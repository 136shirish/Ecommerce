package com.ecommerce.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.project.DTO.PaymentDTO;

import com.ecommerce.project.service.PaymentService;


@RestController
@RequestMapping("/api/v1/payment")
public class PaymentController {
	@Autowired
	private PaymentService paymentService;
	@PostMapping("/save")
	public Long savePayment(@RequestBody PaymentDTO paymentDTO) {
	    PaymentDTO savedPayment = paymentService.processPayment(paymentDTO);
	    return savedPayment.getPaymentId();
	}
	@GetMapping("/getAllPayment")
	public List<PaymentDTO> getAllPayment(){
		List<PaymentDTO> allPayments=paymentService.getAllPayments();
		return allPayments;
		
	}
	@DeleteMapping("/deletePayment/{id}")
	public String deletePayment(@PathVariable(value = "id") Long id) {
	    boolean deletePayment = paymentService.deletePayment(id);
	    if (deletePayment) {
	        return "Payment deleted successfully";
	    } else {
	        return "Payment not found";
	    }
	}



}
