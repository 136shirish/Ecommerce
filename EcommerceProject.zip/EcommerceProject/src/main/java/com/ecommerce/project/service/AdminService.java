package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.AdminDTO;
import com.ecommerce.project.DTO.ProductDTO;
import com.ecommerce.project.model.Admin;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.User;

public interface AdminService {
    List<Admin> getAllAdmins();
    Admin getAdminById(Long adminId);
    Admin createAdmin(AdminDTO adminDTO);
    void deleteAdmin(Long adminId);
    List<User> getAllUsers();
    User getUserById(Long userId);
    void deleteUser(Long userId);
    List<Product> getAllProducts();
    Product getProductById(Long productId);
    String createProduct(ProductDTO productDTO);
    void deleteProduct(Long productId);
}

