package com.ecommerce.project.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.AdminDTO;
import com.ecommerce.project.DTO.ProductDTO;
import com.ecommerce.project.model.Admin;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.User;
import com.ecommerce.project.repository.AdminRepo;
import com.ecommerce.project.repository.ProductRepo;
import com.ecommerce.project.repository.UserRepo;

@Service
public class AdminServiceIMP implements AdminService{
	
	@Autowired
	private AdminRepo adminRepo;
	@Autowired
	private UserRepo userRepo;
	@Autowired
	private ProductRepo productRepo;

	@Override
	public List<Admin> getAllAdmins() {
		return adminRepo.findAll();
	}

	@Override
	public Admin getAdminById(Long adminId) {
		
		return adminRepo.findById(adminId)
                .orElseThrow(() -> new NoSuchElementException("Admin not found"));
	}

	@Override
	public Admin createAdmin(AdminDTO adminDTO) {
		Admin admin = new Admin(adminDTO.getUsername(), adminDTO.getPassword());
		return adminRepo.save(admin);
	}

	@Override
	public void deleteAdmin(Long adminId) {
		 adminRepo.deleteById(adminId);
		
	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User getUserById(Long userId) {
		return userRepo.findById(userId)
        .orElseThrow(() -> new NoSuchElementException("User not found"));
	}

	@Override
	public void deleteUser(Long userId) {
		userRepo.deleteById(userId);
		
	}

	@Override
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	@Override
	public Product getProductById(Long productId) {
		return productRepo.findById(productId)
        .orElseThrow(() -> new NoSuchElementException("Product not found"));
	}

	@Override
	public String createProduct(ProductDTO productDTO) {
		 Product product = new Product();
	        product.setItemname(productDTO.getItemName());
	        product.setDescription(productDTO.getDescription());
	        product.setPrice(productDTO.getPrice());
	        product.setQuantity(productDTO.getQuantity());
	        product.setSize(productDTO.getSize());
	        product.setCategoryname(productDTO.getCategoryName());
	        product.setImage(productDTO.getImage());
	        Product savedProduct = productRepo.save(product);
	        return savedProduct.getItemname();
	}

	@Override
	public void deleteProduct(Long productId) {
		 productRepo.deleteById(productId);
	}

}
