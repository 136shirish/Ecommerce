package com.ecommerce.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.CartDTO;
import com.ecommerce.project.model.Cart;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.model.User;
import com.ecommerce.project.repository.CartRepo;
import com.ecommerce.project.repository.ProductRepo;
import com.ecommerce.project.repository.UserRepo;
@Service
public class CartServiceIMP implements CartService{
	@Autowired
	private CartRepo cartRepo;
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private UserRepo userRepo;

	@Override
	public CartDTO getCartById(long cartId) {
		Cart cart = cartRepo.findById(cartId).orElse(null);
        if (cart != null) {
            CartDTO cartDTO = new CartDTO();
            cartDTO.setId(cart.getId());
            cartDTO.setUserId(cart.getUser().getUserid());
            // Set other necessary fields in the DTO
            return cartDTO;
        }
        return null;
	}

	@Override
	public void addProductToCart(long userId, long productId) {
	    Cart cart = cartRepo.findByUserId(userId);
	    if (cart == null) {
	        cart = new Cart();
	        User user = userRepo.findById(userId).orElse(null);
	        if (user != null) {
	            cart.setUser(user);
	            cartRepo.save(cart); 
	        } else {
	            throw new IllegalArgumentException("User with ID " + userId + " doesn't exist.");
	        }
	    }

	    Product product = productRepo.findById(productId).orElse(null);
	    if (product != null) {
	        cart.addProduct(product);
	        cartRepo.save(cart);
	    } else {
	        throw new IllegalArgumentException("Product with ID " + productId + " doesn't exist.");
	    }
	}



	@Override
	public void removeProductFromCart(long cartId, long productId) {
		Cart cart = cartRepo.findById(cartId).orElse(null);
        if (cart != null) {
            Product product = productRepo.findById(productId).orElse(null);
            if (product != null) {
                cart.removeProduct(product);
                cartRepo.save(cart);
            } else {
            	throw new IllegalArgumentException("Product with ID " + productId + " doesn't exist.");
            }
        } else {
        	throw new IllegalArgumentException("Cart with ID " + cartId + " doesn't exist.");
        }
		
	}

	@Override
	public void deleteCart(long cartId) {
		cartRepo.deleteById(cartId);
		
	}

}
