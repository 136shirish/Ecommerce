package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.OrderDetailDTO;
import com.ecommerce.project.model.OrderDetail;

public interface OrderDetailService {
	OrderDetail placeOrder(OrderDetailDTO orderDetailDTO);
	OrderDetail getorderDetailById(Long orderId);
	List<OrderDetail>getAllOrderDetails();
	
}
