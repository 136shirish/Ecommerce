package com.ecommerce.project.service;

import java.util.List;

import com.ecommerce.project.DTO.ProductDTO;

public interface ProductService {
	String createProduct(ProductDTO productDTO);
	ProductDTO getProductById(long id);
	List<ProductDTO> getAllProducts();
	String updateProduct(long id, ProductDTO productDTO);
	boolean deleteProduct(long id);

}
