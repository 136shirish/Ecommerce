package com.ecommerce.project.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.project.DTO.ProductDTO;
import com.ecommerce.project.exception.ProductNotFoundException;
import com.ecommerce.project.model.Product;
import com.ecommerce.project.repository.ProductRepo;

@Service
public class ProductServiceIMP implements ProductService {

    @Autowired
    private ProductRepo productRepo;

    @Override
    public String createProduct(ProductDTO productDTO) {
        Product product = new Product();
        product.setItemname(productDTO.getItemName());
        product.setDescription(productDTO.getDescription());
        product.setPrice(productDTO.getPrice());
        product.setQuantity(productDTO.getQuantity());
        product.setSize(productDTO.getSize());
        product.setCategoryname(productDTO.getCategoryName());
        product.setImage(productDTO.getImage());
        Product savedProduct = productRepo.save(product);
        return savedProduct.getItemname();
    }

    @Override
    public ProductDTO getProductById(long id) {
        Product product = productRepo.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product Not Found"));

        ProductDTO productDTO = new ProductDTO(
                product.getProductid(),
                product.getItemname(),
                product.getDescription(),
                product.getPrice(),
                product.getQuantity(),
                product.getSize(),
                product.getCategoryname(),
                product.getImage()
        );

        return productDTO;
    }

    @Override
    public List<ProductDTO> getAllProducts() {
        List<Product> products = productRepo.findAll();
        List<ProductDTO> productDTOList = new ArrayList<>();

        for (Product product : products) {
            ProductDTO productDTO = new ProductDTO(
                    product.getProductid(),
                    product.getItemname(),
                    product.getDescription(),
                    product.getPrice(),
                    product.getQuantity(),
                    product.getSize(),
                    product.getCategoryname(),
                    product.getImage()
            );

            productDTOList.add(productDTO);
        }

        return productDTOList;
    }

    @Override
    public String updateProduct(long id, ProductDTO productDTO) {
        Product existingProduct = productRepo.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product Not Found"));

        existingProduct.setItemname(productDTO.getItemName());
        existingProduct.setDescription(productDTO.getDescription());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setQuantity(productDTO.getQuantity());
        existingProduct.setSize(productDTO.getSize());
        existingProduct.setCategoryname(productDTO.getCategoryName());
        existingProduct.setImage(productDTO.getImage());

        Product updatedProduct = productRepo.save(existingProduct);
        return updatedProduct.getItemname();
    }

    @Override
    public boolean deleteProduct(long id) {
        if (productRepo.existsById(id)) {
            productRepo.deleteById(id);
            return true;
        } else {
            throw new ProductNotFoundException("Product Not Found");
        }
    }
}
