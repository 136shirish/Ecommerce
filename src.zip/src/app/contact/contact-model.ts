export interface Contact{
 name:String;
 email:String;
 message:String;
}