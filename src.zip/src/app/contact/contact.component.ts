import { Component } from '@angular/core';
import { Contact } from './contact-model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent {
  name: string ="";
  email: string = "";
  message: string = "";
  
  
  constructor(private http: HttpClient )
  {
  }
  save()
  {
  
    let bodyData = {
     "name": this.name,
     "email": this.email,
     "message": this.message
     

    };
    this.http.post("http://localhost:8084/api/v1/contact/save",bodyData,{responseType: 'text'}).subscribe((resultData: any)=>
    {
        console.log(resultData);
        alert("Contact Sended Successfully");
    });
  }
}
