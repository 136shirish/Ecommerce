import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { AddCategoryComponent } from './components/add-category/add-category.component';
import { ViewCustomerComponent } from './components/view-customer/view-customer.component';
import { FeedbackComponent } from 'src/app/feedback/feedback.component';
import { ViewOrderComponent } from './components/view-order/view-order.component';
import { ViewPaymentComponent } from './components/view-payment/view-payment.component';
import { ViewFeedbackComponent } from './components/view-feedback/view-feedback.component';

const routes: Routes = [
  {path:'',component:AdminDashboardComponent,
  children:[
    {path:'home',component:HomeComponent},
    {path:'addProduct',component:AddProductComponent},
    {path:'addCategory',component:AddCategoryComponent},
    {path:'viewCustomer',component:ViewCustomerComponent},
    {path:'viewOrder',component:ViewOrderComponent},
    {path:'viewFeedback',component:ViewFeedbackComponent},
    {path:'viewPayment',component:ViewPaymentComponent},
    {path:'',redirectTo:'/admin/home',pathMatch:'full'},

  ],
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
