import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { AddCategoryComponent } from './components/add-category/add-category.component';
import { ViewCustomerComponent } from './components/view-customer/view-customer.component';
import { ViewFeedbackComponent } from './components/view-feedback/view-feedback.component';
import { ViewOrderComponent } from './components/view-order/view-order.component';
import { ViewPaymentComponent } from './components/view-payment/view-payment.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AdminDashboardComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AddProductComponent,
    AddCategoryComponent,
    ViewCustomerComponent,
    ViewFeedbackComponent,
    ViewOrderComponent,
    ViewPaymentComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule
  ]
})
export class AdminModule { }
