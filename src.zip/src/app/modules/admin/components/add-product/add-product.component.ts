import { Component, OnInit } from '@angular/core';
import { product } from './product-model';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})

export class AddProductComponent implements OnInit {
  product: product = {
    itemName: '',
    description: '',
    price: 0,
    categoryName: '',
    image: '',
    productid: 0
  };

  savedProducts: product[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchProducts(); 
  }

  addProduct() {
    this.http.post('http://localhost:8084/api/v1/product/save', this.product).subscribe(
      (response) => {
        console.log('Product saved successfully:', response);
        this.clearForm();
        this.fetchProducts(); 
      },
      (error) => {
        console.error('Error saving product:', error);
      }
    );
  }

  fetchProducts() {
    this.http.get<product[]>('http://localhost:8084/api/v1/product/getAllproduct').subscribe(
      (response) => {
        this.savedProducts = response;
      },
      (error) => {
        console.error('Error fetching products:', error);
      }
    );
  }

  clearForm() {
    this.product = {
      productid: 0,
      itemName: '',
      description: '',
      price: 0,
      categoryName: '',
      image: ''
    };
  }
  updateProduct(product: product) {
    // Implement the update logic here
    console.log('Update product:', product);
  }

  deleteProduct(product: product) {
    // Implement the delete logic here
    console.log('Delete product:', product);
  }
}
