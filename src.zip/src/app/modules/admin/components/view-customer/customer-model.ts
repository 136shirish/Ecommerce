export  interface customer{
    
    firstname:string;
    lastname:string;
    email:string;
    password:string;

}