export  interface feedback{
    
    name:string;
    email:string;
    feedback:string;

}