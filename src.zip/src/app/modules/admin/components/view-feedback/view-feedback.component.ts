import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { feedback } from './feedback-model';
import { ApiService } from 'src/app/shared/api.service';

@Injectable({
  providedIn:'root'
})

@Component({
  selector: 'app-view-feedback',
  templateUrl: './view-feedback.component.html',
  styleUrls: ['./view-feedback.component.css']
})
export class ViewFeedbackComponent implements OnInit{
  
  feedbacks: feedback[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchFeedbacks();
  }

  fetchFeedbacks() {
    this.http.get<feedback[]>('http://localhost:8084/api/v1/feedback/getAllfeedback').subscribe(
      (response) => {
        this.feedbacks = response;
      },
      (error) => {
        console.error('Error fetching feedbacks:', error);
      }
    );
  }
  
}
