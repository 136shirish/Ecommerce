export interface Order {
    fullName: string;
    email: string;
    address: string;
    contactNumber:number;
  }
  