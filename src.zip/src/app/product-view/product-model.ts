export  interface product{
    productid:number;
    itemName:string;
    description:string;
    price:number;
    categoryName:string;
    image:string;

}