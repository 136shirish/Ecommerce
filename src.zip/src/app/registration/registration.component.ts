import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {
  name: string ="";
  email: string = "";
  password: string = "";
  cpassword: string = "";
  
  constructor(private http: HttpClient )
  {
  }
  save()
  {
  
    let bodyData = {
     "name": this.name,
     "email": this.email,
     "password": this.password,
     "cpassword": this.cpassword

    };
    this.http.post("http://localhost:8084/api/v1/register/save",bodyData,{responseType: 'text'}).subscribe((resultData: any)=>
    {
        console.log(resultData);
        alert("User Registered Successfully");
    });
  }
}